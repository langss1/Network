# web_server_single_persistent.py
import socket
import os

HOST = '127.0.0.1'
PORT = 6789

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(5)

print(f"Server berjalan di http://{HOST}:{PORT}/")

client_active = False

while True:
    print("\nMenunggu koneksi dari client...")
    conn, addr = server_socket.accept()
    print(f"Mencoba koneksi dari {addr}...")

    if client_active:
        print("Client lain sedang aktif. Menolak koneksi.")
        response = "HTTP/1.1 503 Service Unavailable\r\n\r\n<h1>503 Server Busy</h1>"
        conn.sendall(response.encode())
        conn.close()
        continue

    client_active = True
    print(f"Terhubung dengan client: {addr}")

    try:
        conn.settimeout(10)  # Supaya tidak menggantung selamanya jika browser diam
        while True:
            try:
                request = conn.recv(1024).decode()
            except socket.timeout:
                print("Timeout, koneksi ditutup oleh server.")
                break

            if not request:
                print("Client menutup koneksi.")
                break

            print(f"\nRequest diterima:\n{request}")
            lines = request.splitlines()
            if not lines:
                continue

            request_line = lines[0]
            try:
                filename = request_line.split()[1][1:]  # Hilangkan '/' awal
            except IndexError:
                filename = "index.html"

            if filename == "":
                filename = "index.html"

            if os.path.isfile(filename):
                with open(filename, 'rb') as f:
                    content = f.read()
                response_header = "HTTP/1.1 200 OK\r\n"
                response_header += "Content-Type: text/html\r\n"
                response_header += f"Content-Length: {len(content)}\r\n"
                response_header += "Connection: keep-alive\r\n"
                response_header += "\r\n"
                conn.sendall(response_header.encode() + content)
            else:
                response = "HTTP/1.1 404 Not Found\r\nConnection: keep-alive\r\n\r\n<h1>404 Not Found</h1>"
                conn.sendall(response.encode())

    except Exception as e:
        print("Terjadi kesalahan:", e)
    finally:
        conn.close()
        client_active = False
        print("Selesai melayani client.")
