import socket
import threading
import os

HOST = '127.0.0.1'  # Dengarkan dari semua IP
PORT = 6789

def handle_client(conn, addr):
    print(f"[+] Terhubung dengan {addr}")
    try:
        request = conn.recv(1024).decode()
        print(f"\n[Request dari {addr}]:\n{request}")

        if not request:
            conn.close()
            return

        lines = request.splitlines()
        if not lines:
            return

        request_line = lines[0]
        try:
            filename = request_line.split()[1][1:]  # Hilangkan '/'
        except IndexError:
            filename = "index.html"

        if filename == "":
            filename = "index.html"

        if os.path.isfile(filename):
            with open(filename, 'rb') as f:
                content = f.read()
            response_header = "HTTP/1.1 200 OK\r\n"
            response_header += "Content-Type: text/html\r\n"
            response_header += f"Content-Length: {len(content)}\r\n"
            response_header += "Connection: close\r\n"
            response_header += "\r\n"
            conn.sendall(response_header.encode() + content)
        else:
            response = "HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n<h1>404 Not Found</h1>"
            conn.sendall(response.encode())

    except Exception as e:
        print(f"[!] Kesalahan saat menangani {addr}: {e}")
    finally:
        conn.close()
        print(f"[-] Koneksi dengan {addr} ditutup")

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen(5)
    print(f"[*] Server berjalan di http://{HOST}:{PORT}/")

    try:
        while True:
            conn, addr = server_socket.accept()
            client_thread = threading.Thread(target=handle_client, args=(conn, addr))
            client_thread.start()
            print(f"[=] Thread untuk {addr} dimulai")
    except KeyboardInterrupt:
        print("\n[!] Server dihentikan oleh pengguna.")
    finally:
        server_socket.close()

if __name__ == "__main__":
    start_server()
