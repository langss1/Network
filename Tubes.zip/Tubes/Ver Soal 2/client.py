import socket
import sys

def http_get_request(host, port, filename):
    # Buat socket TCP
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        # Terhubung ke server
        client_socket.connect((host, port))

        # Buat request HTTP GET
        request_line = f"GET /{filename} HTTP/1.1\r\n"
        headers = f"Host: {host}:{port}\r\n"
        headers += "Connection: close\r\n"
        headers += "\r\n"
        http_request = request_line + headers

        # Kirim request ke server
        client_socket.sendall(http_request.encode())

        # Terima dan tampilkan response dari server
        response = b""
        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            response += data

        # Decode dan tampilkan hasil respons
        print("== RESPONSE DARI SERVER ==")
        print(response.decode(errors='replace'))

    except Exception as e:
        print("Terjadi kesalahan:", e)
    finally:
        client_socket.close()

if len(sys.argv) != 4:
    print("Penggunaan: python client.py <server_host> <server_port> <filename>")
    sys.exit(1)

server_host = sys.argv[1]
server_port = int(sys.argv[2])
filename = sys.argv[3]

http_get_request(server_host, server_port, filename)
